<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\subPatologias;
use Faker\Generator as Faker;

$factory->define(subPatologias::class, function (Faker $faker) {
    return [
        //
    ];
});
