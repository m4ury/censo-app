<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Estadistica extends Model
{

}
