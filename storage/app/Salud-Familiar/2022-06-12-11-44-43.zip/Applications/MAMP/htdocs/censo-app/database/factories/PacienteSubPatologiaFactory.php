<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\PacienteSubPatologia;
use Faker\Generator as Faker;

$factory->define(PacienteSubPatologia::class, function (Faker $faker) {
    return [
        //
    ];
});
