<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Familia;
use Faker\Generator as Faker;

$factory->define(Familia::class, function (Faker $faker) {
    return [
        //
    ];
});
