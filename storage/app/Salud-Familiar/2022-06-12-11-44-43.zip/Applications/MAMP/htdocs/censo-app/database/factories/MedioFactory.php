<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Medio;
use Faker\Generator as Faker;

$factory->define(Medio::class, function (Faker $faker) {
    return [
        //
    ];
});
