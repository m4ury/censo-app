<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Movimiento;
use Faker\Generator as Faker;

$factory->define(Movimiento::class, function (Faker $faker) {
    return [
        //
    ];
});
